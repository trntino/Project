from setuptools import setup, find_packages
import os
import deloqv

setup(name = 'deloqv',
      version = '0.0.1',
      url='https://github.com/ELKHMISSI/Project.git',
      author = 'EL KHMISSI, NIASSE, FONTANA',
      author_email = 'mohamed.el-khmissi01@etu.umontpellier.fr',
      maintainer = 'EL KHMISSI, NIASSE, FONTANA',
      maintainer_email = 'mohamed.el-khmissi01@etu.umontpellier.fr',
      keywords = 'Prices distances south France highways',
      packages = ['deloqv'],
      description = 'voir presentation',
      license = 'MIT',
      platforms = 'ALL',
     )